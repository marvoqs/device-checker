import React, { FC } from 'react';
import { Route, Redirect } from 'react-router-dom';
import { useSelector } from 'react-redux';

interface PrivateRouteProps {
  component: FC;
  exact: boolean;
  path: string;
}

const PrivateRoute: FC<PrivateRouteProps> = ({ component: Component, ...rest }) => {
  const { isAuthenticated, loading } = useSelector((state: StateType) => state.auth);

  return <Route {...rest} render={(props) => (!isAuthenticated && !loading ? <Redirect to='/login' /> : <Component {...props} />)} />;
};

export default PrivateRoute;

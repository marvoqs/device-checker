import React from 'react';

const DevicesList: React.FC = () => {
  return <div>Devices List</div>;
};

export default DevicesList;

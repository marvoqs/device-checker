interface IUser {
  id: string;
  type: string;
  login: string;
  name: string;
  token: string;
}

interface AuthContext {
  state: AuthState;
  dispatch?: any;
}

interface AuthState {
  user: IUser | null;
  loading: boolean;
  error: string | null;
}

interface AuthAction {
  type: string;
  payload?: any;
  error?: string;
}

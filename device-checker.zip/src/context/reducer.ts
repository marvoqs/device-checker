let user: IUser = localStorage.getItem('currentUser') ? JSON.parse(localStorage.getItem('currentUser') as string).user : null;

export const initialState: AuthState = {
  user: user || null,
  loading: false,
  error: null,
};

export const AuthReducer = (initialState: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'REQUEST_LOGIN':
      return {
        ...initialState,
        loading: true,
      };
    case 'LOGIN_SUCCESS':
      return {
        ...initialState,
        user: action.payload.user,
        loading: false,
      };
    case 'LOGOUT':
      return {
        ...initialState,
        user: null,
      };
    case 'LOGIN_ERROR':
      return {
        ...initialState,
        loading: false,
        error: action.error ? action.error : null,
      };

    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
};
